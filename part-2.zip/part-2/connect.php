<?php
	$host = "localhost";
	$username = "root";
	$password = "";
	$database = "sg_daftar";//parameter databasenya

	$connect = mysqli_connect($host,$username, $password,$database);

	if (!$connect) {
		die("ga masuk bapak".mysqli_connect_error());# code...
	}
	echo "Selamat,terConnect";
?>