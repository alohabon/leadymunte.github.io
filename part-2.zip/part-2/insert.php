
<?php
	require_once 'connect.php';
	if (isset($_POST)) {
		//print_r($_POST);# code...

		$nama = $_POST["nama"];
		$username = $_POST["username"];
		$password = $_POST["password"];
		$email = $_POST["email"];
		$ttl = $_POST["ttl"];
		$jenis_kelamin = $_POST["jk"];
		$nohp = $_POST["nohp"];
		$alamat = $_POST["alamat"];
		$hobi = $_POST["hobi"];
		$jurusan = $_POST["jurusan"];

		// echo "terConnect";

		$sql = "INSERT INTO nama_lengkap VALUES (NULL,'$nama','$username','$password','$email','$ttl','$jenis_kelamin','$nohp','$alamat','$hobi','$jurusan');";

		$insert = mysqli_query($connect,$sql);

		if ($insert) {
			echo "Berhasil Insert";
			}
			else {
				echo "gagal insert".mysqli_error($connect);
			}# code...
		
	}

?>

