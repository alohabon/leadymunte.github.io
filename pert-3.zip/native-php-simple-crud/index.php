<?php
	//get data dari DB
?>
<html>
<head>
	<title>List Peserta Seleksi Study Group TEL-C</title>
</head>

<body>
	<a href="insert.php">Tambah Peserta</a><br/><br/>
		<table border="1">
		<tr>
			<th>Nama Lengkap</th>
			<th>Username</th>
			<th>Password</th>
			<th>E-Mail</th>
			<th>TTL</th>
			<th>Jenis Kelamin</th>
			<th>No Handphone</th>
			<th>Alamat</th>
			<th>Hobi</th>
			<th>Jurusan</th>
			<th>Aksi</th>
		</tr>
		<?php
			require_once 'connect.php';
			$peserta = mysqli_query($connect,"SELECT * from peserta");

			if (mysqli_num_rows($peserta)== 0) {
				# code...
				echo "<tr><td colspan ='11'>Data Tidak Tersedia</td></tr>";
			} else{
				//print_r($peserta);//supaya data dapat dilihat dengan rapi
				//foreach : looping for untuk arrray
				foreach ($peserta as $value) {
					# code...
					echo "<tr>";
						echo "<td>".$value['nama']."</td>";
						echo "<td>".$value['username']."</td>";
						echo "<td>".$value['password']."</td>";
						echo "<td>".$value['email']."</td>";
						echo "<td>".$value['ttl']."</td>";
						echo "<td>".$value['jenis_kelamin']."</td>";
						echo "<td>".$value['nohp']."</td>";
						echo "<td>".$value['alamat']."</td>";
						echo "<td>".$value['hobi']."</td>";
						echo "<td>".$value['jurusan']."</td>";
						echo "<td>
								<a href='delete.php?id=$value[id]'>Delete<a>||
								<a href='edit.php?id=$value[id]'>Edit<a>
								</td>";
					echo "</tr>";
				}
			}
		?>
		</table>

</body>
</html>