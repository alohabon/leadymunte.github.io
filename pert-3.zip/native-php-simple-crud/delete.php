<?php
	// File Untuk delete
	require_once 'connect.php';

	$id=$_GET['id'];

	$sql = "DELETE FROM peserta WHERE id = '$id'";//

	$query = mysqli_query($connect, $sql);
	if (!$query) {
		# code...
		echo "Gagal dihapus";
	}else{
		echo" berhasil di hapus";
	}
	echo "<br><a href ='index.php'> Menu Utama</a>";
?>