<?php
	//ini buat update
	if (isset($_POST['submit'])) {
		# code...
			require_once 'connect.php';
			$id = $_POST['id'];
			$nama = $_POST['nama'];
			$username = $_POST['username'];
			$password = $_POST['password'];
			$email = $_POST['email'];
			$ttl = $_POST['ttl'];
			// $jenis_kelamin = $_POST['jk'];
			$nohp = $_POST['nohp'];
			$alamat = $_POST['alamat'];
			// $hobi = $_POST['hobi'];
			// $jurusan = $_POST['jurusan'];	

			$sql = "UPDATE 
						peserta 
					Set 
						nama = '$nama',
						username = '$username',
						password ='$password',
						email = '$email',
						ttl = '$ttl',
						nohp = '$nohp',
						alamat = '$alamat'
					WHERE
						id = '$id';
						";
			$query = mysqli_query($connect, $sql);
				if (!$query) {
					# code...
					echo "Gagal dihapus";
				}else{
					echo" berhasil di hapus";
				}
				echo "<br><a href ='index.php'> Menu Utama</a>";
	}
?>

<?php
	//ini buat get data edit
	require_once 'connect.php';

	$id = $_GET['id'];

	$sql = "SELECT *FROM peserta WHERE id= '$id' ";

	$query = mysqli_query($connect,$sql);
		if (mysqli_num_rows($query)!=0) {
			# code...
			$peserta = mysqli_fetch_assoc($query);//assoc :untuk mengeluarkan sesuai tabel // array : mengeluarkan 2kali lipat karen indeksnya juga di keluarkan
			echo "<pre>";
				print_r($peserta);
			echo "</pre>";
		}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Edit</title>
</head>
<body>
	<h1>Edit Peserta Pendaftaran TEL-C</h1>
	<form action = "" method="POST">
		<input type="hidden" name="id" value="<?php echo $peserta ['id'] ?>">
		<table>
			<tr>
				<td>Nama Lengkap</td>
				<td>:</td>
				<td><input type="text" name="nama" value="<?php echo $peserta ['nama'] ?>"></td>
			</tr>
			<tr>
				<td>Username</td>
				<td>:</td>
				<td><input type="text" name="username" value="<?php echo $peserta ['username'] ?>"></td>
			</tr>
			<tr>
				<td>Password</td>
				<td>:</td>
				<td><input type="password" name="password" value="<?php echo $peserta ['password'] ?>"></td>
			</tr>
			<tr>
				<td>E-Mail</td>
				<td>:</td>
				<td><input type="email" name="email" value="<?php echo $peserta ['email'] ?>"></td>
			</tr>
			<tr>
				<td>TTL</td>
				<td>:</td>
				<td><input type="date" name="ttl" value="<?php echo $peserta ['ttl'] ?>"></td>
			</tr>
			<tr>
				<td>Jenis Kelamin</td>
				<td>:</td>
				<td>
					<input type="radio" name="jk" value="Laki-laki">Laki-laki 
					<input type="radio" name="jk" value="Perempuan">Perempuan
				</td>
			</tr>
			<tr>
				<td>No HP</td>
				<td>:</td>
				<td><input type="number" name="nohp" value="<?php echo $peserta ['nohp'] ?>"></td>
			</tr>
			<tr>
				<td>Alamat</td>
				<td>:</td>
				<td>
					<textarea name="alamat"><?php echo $peserta ['alamat'] ?></textarea>
				</td>
			</tr>
			<tr>
				<td>Hobi</td>
				<td>:</td>
				<td>
					<input type="checkbox" name="hobi" value="makan">Makan<br>
					<input type="checkbox" name="hobi" value="tidur">Tidur<br>
					<input type="checkbox" name="hobi" value="mandi">Mandi<br>
				</td>
			</tr>
			<tr>
				<td>Jurusan</td>
				<td>:</td>
				<td>
					<select name="jurusan">
						<option value="S1 Teknik Informatika">S1 Teknik Informatika</option>
						<option value="S1 Ilmu Komputasi">S1 Ilmu Komputasi</option>
						<option value="S1 Teknologi Informasi">S1 Teknologi Informasi</option>
					</select>
				</td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td><button type="submit" name="submit">Submit</button><button type="reset">Reset</button></td>
			</tr>
		</table>
	</form>
</body>
</html>